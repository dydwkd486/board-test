package com.ssafy.vue.dao;
import java.util.List;

import org.apache.ibatis.annotations.Mapper;

import com.ssafy.vue.dto.Qna;

@Mapper
public interface QnaDAO {
	public List<Qna> selectQna();
	public Qna selectQnaByNo(int no);
	public int insertQna(Qna qna);
	public int updateQna(Qna qna);
	public int deleteQna(int no);
}

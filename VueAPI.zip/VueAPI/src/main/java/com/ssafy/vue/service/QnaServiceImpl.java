package com.ssafy.vue.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.ssafy.vue.dao.QnaDAO;
import com.ssafy.vue.dto.Qna;

@Service
public class QnaServiceImpl implements QnaService {

	@Autowired
	private QnaDAO qnaDao;
	
	@Override
	public List<Qna> retrieveQna() {
		return qnaDao.selectQna();
	}

	@Override
	public Qna detailQna(int no) {
		return qnaDao.selectQnaByNo(no);
	}

	@Override
	public boolean writeQna(Qna qna) {
		return qnaDao.insertQna(qna) == 1;
	}

	@Override
	public boolean updateQna(Qna qna) {
		return qnaDao.updateQna(qna) == 1;
	}

	@Override
	@Transactional
	public boolean deleteQna(int no) {
		return qnaDao.deleteQna(no) == 1;
	}

}

package com.ssafy.axios;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AxiosApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
